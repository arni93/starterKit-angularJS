package com.capgemini.chess.service;

import java.util.List;

import com.capgemini.chess.to.TaskTO;

public interface TaskService {
	public void addTask(TaskTO task);

	public void removeTask(TaskTO task);

	public void updateTask(TaskTO task);

	public List<TaskTO> getAllTasks();
}
