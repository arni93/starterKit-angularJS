package com.capgemini.chess.dao.impl;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.chess.dao.TaskDao;
import com.capgemini.chess.domain.TaskBO;

@Repository
@Transactional(propagation = Propagation.MANDATORY)
public class TaskDaoImpl extends AbstractDao<TaskBO, Long> implements TaskDao {

}
