package com.capgemini.chess.mapper;

import java.util.List;
import java.util.stream.Collectors;

import com.capgemini.chess.domain.TaskBO;
import com.capgemini.chess.to.TaskTO;

public class TaskMapper {
	private static TaskTO map(TaskBO taskBO) {
		TaskTO taskTO = null;
		if (taskBO != null) {
			taskTO = new TaskTO();
			taskTO.setId(taskBO.getId());
			taskTO.setTitle(taskBO.getTitle());
			taskTO.setCategory(taskBO.getCategory());
			taskTO.setContent(taskBO.getContent());
			taskTO.setDate(taskBO.getDate());
			taskTO.setPriority(taskBO.getPriority());
			taskTO.setStatus(taskBO.getStatus());
			taskTO.setCreationTimestamp(taskBO.getCreationTimestamp());
		}
		return taskTO;
	}

	public static TaskBO map(TaskTO taskTO) {
		TaskBO taskBO = null;
		if (taskTO != null) {
			taskBO = new TaskBO();
			taskBO.setId(taskTO.getId());
			taskBO.setTitle(taskTO.getTitle());
			taskBO.setCategory(taskTO.getCategory());
			taskBO.setContent(taskTO.getContent());
			taskBO.setDate(taskTO.getDate());
			taskBO.setPriority(taskTO.getPriority());
			taskBO.setStatus(taskTO.getStatus());
			taskBO.setCreationTimestamp(taskTO.getCreationTimestamp());
		}
		return taskBO;
	}

	public static List<TaskTO> map2TOs(List<TaskBO> taskBOs) {
		return taskBOs.stream().map(TaskMapper::map).collect(Collectors.toList());
	}

}
