package com.capgemini.chess;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * runs application with spring boot
 * 
 * @author AWOZNICA
 */

@SpringBootApplication
public class TaskManagerServerApplication {
	public static void main(String[] args) {
		SpringApplication.run(TaskManagerServerApplication.class, args);
	}
}
