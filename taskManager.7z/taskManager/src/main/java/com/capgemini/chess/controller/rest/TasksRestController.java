package com.capgemini.chess.controller.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.chess.service.TaskService;
import com.capgemini.chess.to.TaskTO;

@RestController
@ResponseBody
@RequestMapping("/rest/tasks")
public class TasksRestController {
	@Autowired
	private TaskService taskService;

	@CrossOrigin
	@RequestMapping(value = "/new", method = RequestMethod.POST)
	public void addTask(@RequestBody TaskTO task) {
		taskService.addTask(task);
	}

	@CrossOrigin
	@RequestMapping(value = "/deleted", method = RequestMethod.POST)
	public void removeTask(@RequestBody TaskTO task) {
		taskService.removeTask(task);
	}

	@CrossOrigin
	@RequestMapping(value = "/updated", method = RequestMethod.POST)
	public void updateTask(@RequestBody TaskTO task) {
		taskService.updateTask(task);
	}

	@CrossOrigin
	@RequestMapping(value = "/all", method = RequestMethod.GET)
	public List<TaskTO> getAllTasks() {
		return taskService.getAllTasks();
	}
}
