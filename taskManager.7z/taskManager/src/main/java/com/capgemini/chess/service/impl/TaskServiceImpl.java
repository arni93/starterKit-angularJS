package com.capgemini.chess.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.chess.dao.TaskDao;
import com.capgemini.chess.domain.TaskBO;
import com.capgemini.chess.mapper.TaskMapper;
import com.capgemini.chess.service.TaskService;
import com.capgemini.chess.to.TaskTO;

@Service
@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
public class TaskServiceImpl implements TaskService {
	@Autowired
	private TaskDao taskDao;

	@Override
	public void addTask(TaskTO task) {
		taskDao.save(TaskMapper.map(task));
	}

	@Override
	public void removeTask(TaskTO task) {
		taskDao.delete(task.getId());
	}

	@Override
	public void updateTask(TaskTO task) {
		TaskBO taskBO = taskDao.findOne(task.getId());
		taskBO.setCategory(task.getCategory());
		taskBO.setContent(task.getContent());
		taskBO.setDate(task.getDate());
		taskBO.setPriority(task.getPriority());
		taskBO.setStatus(task.getStatus());
		taskBO.setTitle(task.getTitle());
		taskDao.update(taskBO);
	}

	@Override
	public List<TaskTO> getAllTasks() {
		return TaskMapper.map2TOs(taskDao.findAll());
	}

}
