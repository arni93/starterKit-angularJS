package com.capgemini.chess.dao;

import com.capgemini.chess.domain.TaskBO;

public interface TaskDao extends Dao<TaskBO, Long> {

}
